package dataclass

data class Producto(
    val id: Int,
    val nombre: String,
    val precio: Double
)